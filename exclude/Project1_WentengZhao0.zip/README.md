Wenteng Zhao  
2021484728  
CS 6378.002 - Advanced Operating Systems - F20  
Project 1  

---

put project1.cpp and config.txt on $HOME of dc machine

modify CONFIGLOCAL in launcher.sh to the directory of your config.txt in local computer

in launcher.sh, command osascript is for macOS, if necessary, modify it to the command which local OS use

in local machine, run launcher.sh(sh launcher.sh or ./launcher.sh) and see the output in terminal

then run cleanup.sh to kill all process we created